MozRepl [![Build Status](https://travis-ci.org/bard/mozrepl.png)](https://travis-ci.org/bard/mozrepl)
============

## Notice

MozRepl is looking for a maintainer. Please get in touch with `hyperstruct [at] gmail.com` or `luca.greco [at] alcacoop.it`.

## What is it

MozRepl is an extension for Firefox and other Mozilla applications. It listens on a TCP port for connections (by default localhost only) and responds with a shell where you can evaluate JavaScript code, in the browser context as well as in web pages.

## Demo

http://www.youtube.com/watch?v=5RSnHN6S52c

## Documentation

https://github.com/bard/mozrepl/wiki
